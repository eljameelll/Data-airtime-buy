import express from 'express';
import fetch from 'node-fetch';
import admin from 'firebase-admin';

const router = express.Router();
admin.initializeApp({
  credential: admin.credential.applicationDefault()
});
const db = admin.firestore();

router.post('/buy-airtime', async (req,res)=>{
  const { uid, phone, amount, provider } = req.body;
  const userRef = db.collection('users').doc(uid);
  const userSnap = await userRef.get();
  const wallet = userSnap.data().walletBalance;
  if(wallet < amount) return res.status(400).json({error:'Insufficient balance'});
  try{
    const apiRes = await fetch('https://vtpass.com/api/pay', {
      method:'POST',
      headers:{ 'Authorization':'Bearer YOUR_API_KEY', 'Content-Type':'application/json' },
      body: JSON.stringify({ serviceID: provider, phone, amount })
    });
    const data = await apiRes.json();
    if(data.success){
      await userRef.update({
        walletBalance: wallet-amount,
        transactions: [...userSnap.data().transactions,{type:'Airtime',amount,phone,status:'success',date:new Date()}]
      });
      return res.json({success:true,message:'Purchase successful'});
    }else return res.status(400).json({error:data.message});
  }catch(err){ return res.status(500).json({error:'VTU API failed'}); }
});

export default router;